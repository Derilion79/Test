let man = document.querySelector('.input1'),
    woman = document.querySelector('.input2'),
    rost = document.querySelector('.rost'),
    ves = document.querySelector('.massa'),
    rasch = document.querySelector('.rasch'),
    clear = document.querySelector('.clear'),
    imt = 0;

rasch.onclick = function(){
    if(man.checked == true || woman.checked == true){
        if(rost.value !='' && ves.value !='')
        {
            imt = ves.value / (rost.value*rost.value).toFixed(0);
            imt.toFixed(0);
            if(imt <=16){
                alert("Ваш ИМТ = " + imt.toFixed(0) + "\nВыраженный дефицит массы тела");
            }
            else if(imt >= 16 && imt<=18){
                alert("Ваш ИМТ = " + imt.toFixed(0) + "\nНедостаточная (дефицит) масса тела");
            }

            else if(imt >= 18 && imt<=25){
                alert("Ваш ИМТ = " + imt.toFixed(0) + "\nНорма");
            }

            else if(imt >= 25 && imt<=30){
                alert("Ваш ИМТ = " + imt.toFixed(0) + "\nИзбыточная масса тела (предожирение)");
            }

            else if(imt >= 30 && imt<=35){
                alert("Ваш ИМТ = " + imt.toFixed(0) + "\nОжирение 1 степени");
            }

            else if(imt >= 35 && imt<=40){
                alert("Ваш ИМТ = " + imt.toFixed(0) + "\nОжирение 2 степени");
            }

            else if(imt >= 40){
                alert("Ваш ИМТ = " + imt.toFixed(0) + "\nОжирение 3 степени");
            }
        }
        else{
            alert("Введите рост и вес!")
        }
    }
    else{
        alert("Выберите свой пол!");
    }
}
clear.onclick = function(){
    man.checked = false;
    woman.checked = false;
    rost.value = "";
    ves.value = "";
}